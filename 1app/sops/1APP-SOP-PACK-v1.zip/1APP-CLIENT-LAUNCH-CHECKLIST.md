# 1APP Client Launch Checklist

Duplicate this file for every client. Name the copy:

`YYYY-MM-DD — Client Name — 1APP Launch Checklist.md`

## Client Record

- Client:
- Primary contact:
- Quote ID/version:
- Quoted automations:
- Post-trial monthly price:
- Sales owner:
- Implementation owner:
- Target launch date:
- Actual launch date:
- Industry template and version:

## Gate 1 — Quote and Trial

- [ ] Custom quote and trial scope accepted in writing
- [ ] Every automation is listed with scope and exclusions
- [ ] Post-trial monthly price, setup fee, tax, and billing cadence verified
- [ ] 30-day trial start trigger and end date defined
- [ ] No credit card required to start trial confirmed
- [ ] Trial success measures recorded
- [ ] Associate attribution recorded
- [ ] Sales-to-fulfillment handoff accepted

## Gate 2 — Onboarding Information

- [ ] Business identity and contacts verified
- [ ] Services and exclusions documented
- [ ] Service area documented
- [ ] Business hours and after-hours rules documented
- [ ] Emergency and human-escalation rules approved
- [ ] Booking rules approved
- [ ] AI wording and prohibited claims approved
- [ ] Logo and brand assets received
- [ ] Review link verified
- [ ] Required secure access available

## Gate 3 — Account Setup

- [ ] Client account created using naming standard
- [ ] Timezone, currency, locale, and business details verified
- [ ] Only quoted automations and supporting features enabled
- [ ] Named users created
- [ ] Permissions follow least privilege
- [ ] Industry template applied and version recorded
- [ ] Test contact created and excluded from marketing

## Gate 4 — Feature Configuration

Complete only the items included in the accepted quote; mark all others **N/A**.

- [ ] Conversations configured
- [ ] Business messaging channels connected
- [ ] Phone routing configured
- [ ] Missed-call text-back configured
- [ ] Calendar availability, assignment, buffers, and timezone configured
- [ ] Confirmation, reminder, reschedule, and cancellation rules configured
- [ ] CRM stages and owners configured
- [ ] Forms/chat configured
- [ ] Review requests configured
- [ ] AI agent purpose, knowledge, booking, handoff, and safety rules configured
- [ ] Payment/invoice workflow configured when included
- [ ] Internal notifications configured
- [ ] Mobile app access configured

## Gate 5 — Data

- [ ] Import authorization recorded
- [ ] Source file preserved
- [ ] Fields mapped
- [ ] Consent and opt-outs preserved
- [ ] Test import passed
- [ ] Full import reconciled
- [ ] Imported contacts excluded from marketing until approved

## Gate 6 — QA

- [ ] Login and permissions passed
- [ ] Inbound call passed
- [ ] Missed-call text-back passed
- [ ] Two-way text passed
- [ ] Email passed
- [ ] Web form/chat passed
- [ ] Contact deduplication passed
- [ ] Opportunity creation and movement passed
- [ ] Booking and timezone passed
- [ ] Confirmation and reminders passed
- [ ] Reschedule and cancellation passed
- [ ] AI greeting and knowledge passed
- [ ] AI qualification and booking passed
- [ ] Human transfer and emergency behaviour passed
- [ ] Prohibited claims and failure behaviour passed
- [ ] Review request and stop conditions passed
- [ ] Payment/invoice test passed when included
- [ ] Opt-out and suppression passed
- [ ] Internal alerts passed
- [ ] Mobile app login passed
- [ ] No blocker defects remain
- [ ] No major defects remain
- [ ] Rollback plan documented
- [ ] Tony approved launch

## Gate 7 — Training and Acceptance

- [ ] Admin user attended training
- [ ] Client can manage conversations
- [ ] Client can manage opportunities
- [ ] Client can manage appointments
- [ ] Client knows how to pause/escalate automation
- [ ] Client knows how to contact support
- [ ] Live acceptance test passed
- [ ] Written go-live approval recorded

## Gate 8 — Go-Live

- [ ] Live workflows enabled in controlled sequence
- [ ] Monitoring owner assigned
- [ ] Launch confirmation sent
- [ ] Training materials sent
- [ ] Support process sent
- [ ] Day 1 check scheduled
- [ ] Day 7 check scheduled
- [ ] Day 14 check scheduled
- [ ] Day 30 review scheduled
- [ ] Trial clock started only after agreed automation became usable
- [ ] Day 21 conversion-risk review scheduled
- [ ] Day 25 conversion meeting scheduled
- [ ] Day 28 continue/modify/end decision scheduled
- [ ] Post-trial billing requires written conversion approval

## Sign-Off

- Tester:
- Implementation owner:
- Tony approval:
- Client approval:
- Open minor items and due dates:
